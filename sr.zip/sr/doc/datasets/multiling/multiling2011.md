# MultiLing 2011
[Homepage](https://users.iit.demokritos.gr/~ggianna/TAC2011/MultiLing2011.html)

For MultiLing 2011, we provide dataset readers for the (only) MDS task and metrics:
```bash
sacrerouge setup-dataset multiling2011 \
    <output-dir>
```