from sacrerouge.datasets.duc_tac.duc2002.subcommand import DUC2002Subcommand
