from sacrerouge.datasets.duc_tac.duc2006.subcommand import DUC2006Subcommand
