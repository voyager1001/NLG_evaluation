from sacrerouge.datasets.duc_tac.duc2005.subcommand import DUC2005Subcommand
