from sacrerouge.datasets.duc_tac.duc2007.subcommand import DUC2007Subcommand
