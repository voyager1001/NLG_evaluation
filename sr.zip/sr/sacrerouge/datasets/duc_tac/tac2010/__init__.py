from sacrerouge.datasets.duc_tac.tac2010.subcommand import TAC2010Subcommand
