from sacrerouge.datasets.duc_tac.tac2009.subcommand import TAC2009Subcommand
