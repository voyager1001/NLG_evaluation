from sacrerouge.datasets.duc_tac.duc2001.subcommand import DUC2001Subcommand
