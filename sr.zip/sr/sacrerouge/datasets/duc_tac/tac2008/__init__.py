from sacrerouge.datasets.duc_tac.tac2008.subcommand import TAC2008Subcommand
