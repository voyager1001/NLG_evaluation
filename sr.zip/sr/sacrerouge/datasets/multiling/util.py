LANGUAGE_CODES = {
    'arabic': 'ar',
    'chinese': 'zh',
    'czech': 'cs',
    'english': 'en',
    'french': 'fr',
    'greek': 'el',
    'hebrew': 'he',
    'hindi': 'hi',
    'romanian': 'ro',
    'spanish': 'es'
}
