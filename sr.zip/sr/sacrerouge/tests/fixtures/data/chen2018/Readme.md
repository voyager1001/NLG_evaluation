The `gold.jsonl` and `model.jsonl` are 10 reference and system summaries from "Fast Abstractive Summarization with Reinforce-Selected Sentence Rewriting" by Chen and Bansal (2018).
