This directory contains a sample of the English multi-document summarization dataset from MultiLing 2011, used with permission for unit testing.
The metrics for the model summaries were not judged and are subsequently made up.
The ROUGE scores were also randomly assigned.

For more information about the dataset, please see http://multiling.iit.demokritos.gr/file/view/353/tac-2011-multiling-pilot-dataset-all-files-source-texts-human-and-system-summaries-evaluation-data for more information.